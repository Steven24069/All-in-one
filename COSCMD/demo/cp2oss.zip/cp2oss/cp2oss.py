#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import yaml
import argparse
import os
import queue
import logging
from uploader import UploaderOss,UploaderCos,getFileUploader
from qcloud_cos.cos_threadpool import SimpleThreadPool

# ./cp2oss.py  -d /Users/adrian/Downloads/dist -b test01 -p h5

# 遍历目录文件，返回上传文件列表
def dirUploadQueue(upoadDir, bucketPrefix):
    # 文件上传列表，{ 'srcKey': srcKey, 'objectKey': objectKey }
    q = queue.Queue()

    # 获取文件夹绝对路径
    abspath = os.path.abspath(upoadDir)
    # 遍历本地文件夹
    g = os.walk(abspath)
    for path, dir_list, file_list in g:
        for file_name in file_list:
            # 这是绝对路径
            srcKey = os.path.join(path, file_name)
            objectKey = os.path.relpath(srcKey, start=abspath).strip('/')
            objectKey = os.path.join(bucketPrefix, objectKey).strip('/')
            q.put({ 'srcKey': srcKey, 'objectKey': objectKey })
    return q
    
# 加载yml配置文件，拿到对应的密钥
def loadBucketConfig(filename, bucketName):
    with open(filename, 'r') as ymlFile:
        conf = yaml.safe_load(ymlFile)
        if bucketName not in conf['buckets']:
            errmsg = 'Invalid bucket!, --bucket {} 不在配置文件内, 请选择{}'.format(bucketName, ' '.join([x for x in conf['buckets'].keys()]))
            raise Exception(errmsg)
        
        return conf['buckets'][bucketName]

# 多线程上传文件
def processUpload(uploadQueue, bucketCfg):
    # 创建上传的线程池
    pool = SimpleThreadPool()
    uploader = getFileUploader(bucketCfg)
    while not uploadQueue.empty():
        item = uploadQueue.get()
        pool.add_task(uploader.upload_file, item['srcKey'], item['objectKey'])

    pool.wait_completion()
    result = pool.get_result()
    if not result['success_all']:
        print("Not all files upload sucessed. you should retry")


# 单线程上传文件
def processUploadSingle(uploadQueue, bucketCfg):
    uploader = getFileUploader(bucketCfg)
    while not uploadQueue.empty():
        item = uploadQueue.get()
        print(item['objectKey'], bucketCfg['bucket'])
        uploader.upload_file(item['srcKey'], item['objectKey'])

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='把本地文件夹复制到阿里云oss/腾讯云cos.')
    parser.add_argument('-c', '--config', help = '配置文件, 默认是当前目录的config.yml')
    parser.add_argument('-d', '--dir', help = '本地文件夹路径', required = True)
    parser.add_argument('-b', '--bucket', help = '配置文件里的bucket名字', required = True)
    parser.add_argument('-p', '--prefix', help = '对象存储目录，默认空', required = False)

    # 获取参数
    args = parser.parse_args()
    configFile = args.config or 'config.yml'
    upoadDir = args.dir
    bucketPrefix = args.prefix or ''
    bucketName = args.bucket
    print('上传本地目录 {} 到 {}:{}'.format(upoadDir, bucketName, bucketPrefix))

    # 加载配置文件获取oss/cos配置
    bucketCfg = loadBucketConfig(configFile, bucketName)

    uploadQueue = dirUploadQueue(upoadDir, bucketPrefix)

    processUpload(uploadQueue, bucketCfg)

    
    