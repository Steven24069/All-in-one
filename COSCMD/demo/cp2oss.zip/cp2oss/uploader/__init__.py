from .cos import UploaderCos
from .oss import UploaderOss

def getFileUploader(bucketCfg):
    uploader = None
    if bucketCfg['type'] == 'oss':
        uploader = UploaderOss.create_file_uploader(
            bucketCfg['access_id'], bucketCfg['access_key'], 
            bucketCfg['region'], bucketCfg['bucket'])
    elif bucketCfg['type'] == 'cos':
        uploader = UploaderCos.create_file_uploader(
            bucketCfg['secret_id'], bucketCfg['secret_key'], 
            bucketCfg['region'], bucketCfg['bucket'])
    else:
        raise Exception('配置错误', bucketCfg)
    return uploader

__all__ = [
    "UploaderCos",
    "UploaderOss",
    "getFileUploader"
]